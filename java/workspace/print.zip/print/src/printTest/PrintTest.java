package printTest;

public class PrintTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
